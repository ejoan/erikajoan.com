  <div class="clear"></div>
  
  
  <div id="footer">
  Copyright 2011. All Rights Reserved. Design & Developed by Dessign.net</div>

</div><!--//main_container-->
<?php wp_footer(); ?>
</body>
</html>